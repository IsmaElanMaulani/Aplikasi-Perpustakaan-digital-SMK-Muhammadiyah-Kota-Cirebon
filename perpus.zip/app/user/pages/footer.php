<footer class="main-footer">
    <div class="pull-right hidden-xs">
    </div>
    <strong>SMK Muhammadiyah Kota Cirebon. &copy; <?= date('Y'); ?></strong>
</footer>